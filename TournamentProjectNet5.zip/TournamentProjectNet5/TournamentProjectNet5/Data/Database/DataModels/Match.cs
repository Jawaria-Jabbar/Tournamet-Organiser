﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using TournamentProjectNet5.Data.Database.ViewModels;

namespace TournamentProjectNet5.Data.Database.DataModels
{
    public enum Round { RoundOf32=1, RoundOf16=2, QuarterFinal=3, SemiFinal=4, Final=5 }
    
    public class Match
    {
        public Match()
        {
            Players = new List<Player>(); 
            Scores = new List<Score>();
            Result = new Result();
        }
        
        public int MatchId { get; set; }

        public int BracketId { get; set; }
        public virtual Bracket Bracket { get; set; }
        public string MatchName { get; set; }

        public Round RoundNumber { get; set; }

        public bool MatchCompleted { get; set; }

        public virtual List<Player> Players { get; set; }

        public virtual List<Score> Scores { get; set; }

        [NotMapped]
        public Result Result { get; set; }
    }
}
