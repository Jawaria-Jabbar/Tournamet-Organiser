﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TournamentProjectNet5.Data.Database.DataModels
{
    public class Player
    {
        public Player()
        {
            Matches = new List<Match>();
        }
        public int PlayerId { get; set; }

        [Required]
        [MinLength(1,ErrorMessage = "PlayerName requires atleast 1 character.")]
        public string PlayerName { get; set; }

        public virtual List<Match> Matches { get; set; }
    }
}
