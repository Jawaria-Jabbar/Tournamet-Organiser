﻿using System.ComponentModel.DataAnnotations.Schema;
using TournamentProjectNet5.Data.Database.ViewModels;

namespace TournamentProjectNet5.Data.Database.DataModels
{
    public class Score
    {
        public Score()
        {
            Result = new Result();
        }

        public int ScoreId { get; set; }
        public int ScoreAmount { get; set; }

        public int PlayerId { get; set; }
        public virtual Player Player { get; set; }

        public int MatchId { get; set; }
        public virtual Match Match { get; set; }

        [NotMapped]
        public Result Result { get; set; }
    }
}
