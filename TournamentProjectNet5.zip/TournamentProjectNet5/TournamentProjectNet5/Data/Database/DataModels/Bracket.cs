﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using TournamentProjectNet5.Data.Database.ViewModels;

namespace TournamentProjectNet5.Data.Database.DataModels
{
    public class Bracket
    {
        public Bracket()
        {
            Matches = new List<Match>();
            Result = new Result();
        }

        public int BracketId { get; set; }
        public string BracketName { get; set; }
        public virtual List<Match> Matches { get; set; }

        public bool BracketCompleted { get; set; }

        [NotMapped]
        public Result Result { get; set; }

        public int? WinningPlayerId { get; set; }

        public virtual Player WinningPlayer { get; set; }
    }
}