﻿namespace TournamentProjectNet5.Data.Database.ViewModels
{
    public class Result
    {
        public string Message { get; set; }
        public bool IsSuccess { get; set; } 
    }
}
