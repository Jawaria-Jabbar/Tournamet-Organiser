﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using TournamentProjectNet5.Data.Database.DataModels;

namespace TournamentProjectNet5.Data.Database
{
    public class TournamentContext : DbContext
    {

        public TournamentContext()// DbContextOptions<TournamentContext> options) : base(options)   
        {
            var folder = System.Environment.CurrentDirectory;
            DbPath = System.IO.Path.Join(folder, "tournament.db");

        }

        public string DbPath { get; }
        public DbSet<Player> Players { get; set; }
        public DbSet<Match> Matches { get; set; }
        public DbSet<Score> Scores { get; set; }    
        public DbSet<Bracket> Brackets { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            options.UseSqlite($"Data Source={DbPath}");
            options.UseLazyLoadingProxies();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Bracket>(Brackets =>
            {
                Brackets.HasMany(hm => hm.Matches)
                    .WithOne(wo => wo.Bracket)
                    .HasForeignKey(fk => fk.BracketId)
                    .OnDelete(DeleteBehavior.Cascade);
            });


            modelBuilder.Entity<Player>(players =>
            {
                players.HasMany(hm => hm.Matches)
                    .WithMany(wm => wm.Players)
                    .UsingEntity(join => join.ToTable("PlayerMatches"));

            });

            modelBuilder.Entity<Match>(Matches =>
            {
                Matches.HasMany(hm => hm.Players)
                    .WithMany(wm => wm.Matches)
                    .UsingEntity(join => join.ToTable("PlayerMatches"));


                Matches.HasMany(hm => hm.Scores)
                    .WithOne(wo => wo.Match)
                    .HasForeignKey(fk => fk.MatchId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<Score>(Scores =>
            {
                Scores.HasOne(ho => ho.Player)
                    .WithMany()
                    .HasForeignKey(fk => fk.PlayerId);

                Scores.HasOne(ho => ho.Match)
                    .WithMany(wm => wm.Scores)
                    .HasForeignKey(fk => fk.MatchId);


            });

        }
    }
}
