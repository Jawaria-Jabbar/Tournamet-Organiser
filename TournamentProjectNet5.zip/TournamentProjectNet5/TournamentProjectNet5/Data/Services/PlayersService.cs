﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TournamentProjectNet5.Data.Database;
using TournamentProjectNet5.Data.Database.DataModels;

namespace TournamentProjectNet5.Data.Services
{
    public class PlayersService
    {
        private readonly TournamentContext _db;

        public PlayersService(TournamentContext db)
        {
            _db = db;
        }

        public async Task<List<Player>> GetPlayers()
        {
            return await _db.Players.ToListAsync();
        }
        public async Task<Player> GetPlayerById(int id)
        {
            return await _db.Players.FirstOrDefaultAsync(f => f.PlayerId == id);
        }

        public async Task<Player> CreatePlayerAsync(Player player)
        {
            _db.Players.Add(player);
            await _db.SaveChangesAsync();
            return player;
        }



        public async Task<string> RemovePlayer(Player player)
        {
            try
            {
                _db.Players.Remove(player);
                await _db.SaveChangesAsync();
                return $"Player {player.PlayerName} removed succesfully";
            }
            catch (Exception ex)
            {
                return $"Error removing player {player.PlayerName}, {ex.ToString()}";
            }
        }
    }
}
