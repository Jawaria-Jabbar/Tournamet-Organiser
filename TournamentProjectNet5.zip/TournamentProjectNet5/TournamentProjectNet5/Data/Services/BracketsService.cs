﻿using Microsoft.EntityFrameworkCore;
using MoreLinq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TournamentProjectNet5.Data.Database;
using TournamentProjectNet5.Data.Database.DataModels;
using TournamentProjectNet5.Data.Database.ViewModels;

namespace TournamentProjectNet5.Data.Services
{
    public class BracketsService
    {
        private readonly TournamentContext _db;
        private readonly PlayersService _playersService;
        private const int maxPlayers = 32;
        private const int RoundOf32 = 16;
        private const int RoundOf16 = 8;
        private const int QuarterFinal = 4;
        private const int SemiFinal = 2;
        private const int Final = 1;
        private const int maxMatches = 31;

        public BracketsService(TournamentContext db, PlayersService servicePlayers)
        {
            _db = db;
            _playersService = servicePlayers;
        }

        public async Task<List<Bracket>> GetBrackets()
        {
            return await _db.Brackets.ToListAsync();
        }

        public async Task<Bracket> GetBracketById(int id)
        {
            return await _db.Brackets.FirstOrDefaultAsync(f => f.BracketId == id);
        }

        public async Task<Result> GenerateNextRoundAsync(List<Match> matches)
        {
            int currentBracket = matches.FirstOrDefault().BracketId;
            Round currentRound = matches.FirstOrDefault().RoundNumber;

            if (currentRound == Round.Final)
            {
                var bracketToEdit = await _db.Brackets.FindAsync(currentBracket);
                _db.Update(bracketToEdit);
                bracketToEdit.WinningPlayerId = matches.FirstOrDefault().Scores.MaxBy(mb => mb.ScoreAmount).FirstOrDefault().PlayerId;
                bracketToEdit.BracketCompleted = true;
                await _db.SaveChangesAsync();

                return new Result
                {
                    IsSuccess = true,
                    Message = "Tournament Completed"
                };
            }

            Round nextRound = currentRound + 1;

            var winningPlayers = new List<Player>();
            foreach (var match in matches)
            {
                var winningPlayer = match.Scores.MaxBy(mb => mb.ScoreAmount).First();
                winningPlayers.Add(winningPlayer.Player);
            }

            var bracketMatches = _db.Matches.Where(w => w.BracketId == currentBracket && w.RoundNumber == nextRound).ToList();

            var generatedMatches = await GenerateMatchesAsync(bracketMatches, winningPlayers, nextRound);

            foreach (var match in generatedMatches)
            {
                var toEditMatch = _db.Matches.Find(match.MatchId);
                _db.Entry(toEditMatch).CurrentValues.SetValues(match);
            }

            await _db.SaveChangesAsync();

            return new Result
            {
                IsSuccess = true,
                Message = "Testing"
            };
        }

        public async Task<List<Match>> GenerateMatchesAsync(List<Match> matches, List<Player> players, Round round)
        {
            #region Players

            Random random = new Random();
            Round currentRound = round;

            var randomizedPlayers = new List<Player>();
            if (players.Count() > 0)
            {
                randomizedPlayers = players;
                currentRound = matches.FirstOrDefault().RoundNumber;
            }
            else
            {
                randomizedPlayers = await _playersService.GetPlayers();
            }

            int playerAmount = 0;
            switch (currentRound)
            {
                case Round.RoundOf32:
                    playerAmount = 32;
                    break;

                case Round.RoundOf16:
                    playerAmount = 16;
                    break;

                case Round.QuarterFinal:
                    playerAmount = 8;
                    break;

                case Round.SemiFinal:
                    playerAmount = 4;
                    break;

                case Round.Final:
                    playerAmount = 2;
                    break;
            }

            randomizedPlayers = randomizedPlayers.OrderBy(o => random.Next()).Take(playerAmount).ToList();
            randomizedPlayers.ForEach(player => _db.Players.Attach(player));

            while (randomizedPlayers.Any())
            {
                var matchtoInsert = matches.Where(w => w.Players.Count() == 0 && w.RoundNumber == currentRound).FirstOrDefault();
                if (matchtoInsert != null)
                {
                    var selectedPlayers = randomizedPlayers.Take(2).ToList();
                    matchtoInsert.Players.AddRange(selectedPlayers);

                    foreach (var player in selectedPlayers)
                    {
                        Score score = new Score();
                        score.Player = player;
                        matchtoInsert.Scores.Add(score);
                    }
                    randomizedPlayers = randomizedPlayers.Skip(2).ToList();
                }
            }

            #endregion Players

            return matches;
        }

        public async Task<Bracket> CreateBracketAsync(Bracket bracket)
        {
            //for(int i =0; i < 200; i++)
            //{
            //    Player player = new Player();
            //    player.PlayerName = $"Player {i}";
            //    _db.Players.Add(player);
            //}
            //await _db.SaveChangesAsync();

            List<Match> matches = new List<Match>();

            #region BracketMatches

            for (int i = 1; i <= RoundOf32; i++)
            {
                matches.Add(new Match { MatchName = $"RoundOf32-Match{i}", RoundNumber = Round.RoundOf32 });
            }
            for (int i = 1; i <= RoundOf16; i++)
            {
                matches.Add(new Match { MatchName = $"RoundOf16-Match{i}", RoundNumber = Round.RoundOf16 });
            }
            for (int i = 1; i <= QuarterFinal; i++)
            {
                matches.Add(new Match { MatchName = $"QuarterFinal-Match{i}", RoundNumber = Round.QuarterFinal });
            }
            for (int i = 1; i <= SemiFinal; i++)
            {
                matches.Add(new Match { MatchName = $"SemiFinal-Match{i}", RoundNumber = Round.SemiFinal });
            }
            for (int i = 1; i <= Final; i++)
            {
                matches.Add(new Match { MatchName = $"Final-Match{i}", RoundNumber = Round.Final });
            }

            #endregion BracketMatches

            Random random = new Random();
            var enoughPlayers = await _playersService.GetPlayers();
            enoughPlayers = enoughPlayers.OrderBy(o => random.Next()).Take(32).ToList();
            enoughPlayers.ForEach(player => _db.Players.Attach(player));

            if (enoughPlayers.Count() != maxPlayers)
            {
                bracket.Result.Message = "Not enough players to fill the bracket";
                bracket.Result.IsSuccess = false;
                return bracket;
            }

            matches = await GenerateMatchesAsync(matches, enoughPlayers, Round.RoundOf32);

            if (matches.Count() == maxMatches)
            {
                bracket.Matches.AddRange(matches);
                _db.Brackets.Add(bracket);
                await _db.SaveChangesAsync();
                bracket.Result.Message = $"Bracket: {bracket.BracketName} succesfully created";
                bracket.Result.IsSuccess = true;
                return bracket;
            }
            else
            {
                bracket.Result.Message = $"Bracket: {bracket.BracketName} didn't create succesfully, please try again later.";
                bracket.Result.IsSuccess = false;
                return bracket;
            }
        }

        public async Task<String> UpdateBracketName(Bracket bracket, String newName)
        {
            _db.Update(bracket);
            bracket.BracketName = newName;
            await _db.SaveChangesAsync();
            return $"Bracket {bracket.BracketName} changed succesfully"; ;
        }

        public async Task<string> RemoveBracket(Bracket bracket)
        {
            try
            {
                _db.Brackets.Remove(bracket);
                await _db.SaveChangesAsync();
                return $"Bracket {bracket.BracketName} removed succesfully";
            }
            catch (Exception ex)
            {
                return $"Error removing Bracket {bracket.BracketName}, {ex.ToString()}";
            }
        }
    }
}