﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TournamentProjectNet5.Data.Database;
using TournamentProjectNet5.Data.Database.DataModels;

namespace TournamentProjectNet5.Data.Services
{
    public class MatchesService
    {
        private readonly TournamentContext _db;

        public MatchesService(TournamentContext db)
        {
            _db = db;
        }

        public async Task<List<Match>> GetMatches()
        {
            return await _db.Matches.ToListAsync();
        }
        public async Task<Match> GetMatchById(int id)
        {
            return await _db.Matches.FirstOrDefaultAsync(f => f.MatchId == id);
        }

        public async Task<Match> CreateMatchAsync(Match match)
        {
            _db.Matches.Add(match);
            await _db.SaveChangesAsync();
            return match;
        }

        public async Task<Match> UpdateMatchAsync(Match match)
        {
            if(match.Scores.Select(s=> s.ScoreAmount).Distinct().Count() == 1)
            {
                match.Result.Message = "Match can't end in a draw";
                match.Result.IsSuccess = false;
                return match;
            }
            Match updateMatch = await _db.Matches.FindAsync(match.MatchId);
            _db.Entry(updateMatch).CurrentValues.SetValues(match);
            await _db.SaveChangesAsync();
            match.Result.Message = "Succesfully updated match";
            match.Result.IsSuccess = true;
            return match;
        }

        public async Task<string> RemoveMatch(Match match)
        {
            try
            {
                _db.Matches.Remove(match);
                await _db.SaveChangesAsync();
                return $"Match {match.MatchName} removed succesfully";
            }
            catch (Exception ex)
            {
                return $"Error removing match {match.MatchName}, {ex.ToString()}";
            }
        }
    }
}
