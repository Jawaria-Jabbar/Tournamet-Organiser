﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TournamentProjectNet5.Data.Database;
using TournamentProjectNet5.Data.Database.DataModels;

namespace TournamentProjectNet5.Data.Services
{
    public class ScoresService
    {
        private readonly TournamentContext _db;

        public ScoresService(TournamentContext db)
        {
            _db = db;
        }
        public async Task<List<Score>> GetScores()
        {
            return await _db.Scores.ToListAsync();
        }
        public async Task<Score> GetScoreById(int id)
        {
            return await _db.Scores.FirstOrDefaultAsync(f => f.ScoreId == id);
        }
        public async Task<Score> CreateScoreAsync(Match match, Player player,int scoreAmount)
        {

            //Check if match score already exists
            if (match.Scores.Where(w => w.PlayerId == player.PlayerId).Count() >= 1)
            {
                Score updateScore = await _db.Scores.Where(w=> w.PlayerId == player.PlayerId && w.MatchId == match.MatchId).FirstOrDefaultAsync();
                _db.Scores.Update(updateScore);
                updateScore.ScoreAmount = scoreAmount;
                await _db.SaveChangesAsync();
                updateScore.Result.IsSuccess = true;
                updateScore.Result.Message = "";
                return updateScore;
            }
            return new Score()
            {
                Result = { IsSuccess = false, Message = "Error"}
            };
        }



        public async Task<string> RemoveScore(Score score)
        {
            try
            {
                _db.Scores.Remove(score);
                await _db.SaveChangesAsync();
                return $"Score {score.ScoreId} removed succesfully";
            }
            catch (Exception ex)
            {
                return $"Error removing player {score.ScoreId}, {ex.ToString()}";
            }
        }
    }
}
