﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TournamentProjectNet5.Migrations
{
    public partial class BracketChanges : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "BracketCompleted",
                table: "Brackets",
                type: "INTEGER",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<int>(
                name: "WinningPlayerId",
                table: "Brackets",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Brackets_WinningPlayerId",
                table: "Brackets",
                column: "WinningPlayerId");

            migrationBuilder.AddForeignKey(
                name: "FK_Brackets_Players_WinningPlayerId",
                table: "Brackets",
                column: "WinningPlayerId",
                principalTable: "Players",
                principalColumn: "PlayerId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Brackets_Players_WinningPlayerId",
                table: "Brackets");

            migrationBuilder.DropIndex(
                name: "IX_Brackets_WinningPlayerId",
                table: "Brackets");

            migrationBuilder.DropColumn(
                name: "BracketCompleted",
                table: "Brackets");

            migrationBuilder.DropColumn(
                name: "WinningPlayerId",
                table: "Brackets");
        }
    }
}
