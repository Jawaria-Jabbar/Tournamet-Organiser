﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TournamentProjectNet5.Migrations
{
    public partial class MatchCompleted : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "MatchCompleted",
                table: "Matches",
                type: "INTEGER",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "MatchCompleted",
                table: "Matches");
        }
    }
}
